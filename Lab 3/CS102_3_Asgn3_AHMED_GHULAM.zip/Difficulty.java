interface Difficulty {
    void setDifficulty(int difficulty);
    int getDifficulty();
}
