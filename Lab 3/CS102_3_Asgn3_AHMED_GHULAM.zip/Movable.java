import java.awt.*;

interface Movable{
    public void move();
    public Point getLocation();
}