public interface ArrayGenerator{
    public Integer[] generate(int n);
}